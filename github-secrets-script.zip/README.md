# GitHub Secret Management Script

This script adds your wallet private key as a secret to all repositories in your GitHub account.

## Prerequisites

1. Install `curl` and `jq` on your system.
2. Create a GitHub Personal Access Token (PAT) with `repo` and `admin:repo_hook` permissions.

## Setup

1. Clone this repository or unzip the provided files.
2. Copy `.env.example` to `.env` and fill in your `GITHUB_PAT` and `PRIVATE_KEY` values.

```bash
cp .env.example .env
```

3. Make the script executable:

```bash
chmod +x add-secrets.sh
```

## Usage

Run the script:

```bash
./add-secrets.sh
```

## Notes

- Ensure your `.env` file is not shared or committed to version control.
- This script fetches all repositories under your GitHub username and adds the private key as a secret.
