#!/bin/bash

# Load environment variables from .env file
if [ -f .env ]; then
  export $(cat .env | grep -v '#' | awk '/=/ {print $1}')
else
  echo ".env file not found. Please create it and add your GITHUB_PAT and PRIVATE_KEY."
  exit 1
fi

# Check for required environment variables
if [ -z "$GITHUB_PAT" ] || [ -z "$PRIVATE_KEY" ]; then
  echo "GITHUB_PAT and PRIVATE_KEY must be set in the .env file."
  exit 1
fi

# Your GitHub username
GITHUB_USERNAME="OKEAMAH"

# Function to add a secret to a repository
add_secret_to_repo() {
  local repo_name=$1

  # URL encode the private key
  ENCODED_PRIVATE_KEY=$(echo -n "$PRIVATE_KEY" | jq -sRr @uri)

  # Add secret to the repository
  curl -X PUT     -H "Authorization: token $GITHUB_PAT"     -H "Accept: application/vnd.github.v3+json"     -d "{"encrypted_value":"$ENCODED_PRIVATE_KEY","key_id":""}"     "https://api.github.com/repos/$GITHUB_USERNAME/$repo_name/actions/secrets/WALLET_PRIVATE_KEY"
}

# Get all repositories for the user
repos=$(curl -s   -H "Authorization: token $GITHUB_PAT"   -H "Accept: application/vnd.github.v3+json"   "https://api.github.com/users/$GITHUB_USERNAME/repos" | jq -r '.[].name')

# Loop through all repositories and add the secret
for repo in $repos; do
  echo "Adding private key to repository: $repo"
  add_secret_to_repo $repo
done
